import requests
import base64

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36'

class browser:
    def get_url(self,url,headers=False,post=False):
        self.url = url
        self.headers = headers
        self.post = post
        if not self.headers:
            self.headers = {'User-Agent': UA, 'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'}
        if self.post:
            try:
                req = requests.post(url=self.url,headers=self.headers,data=self.post,timeout=12)
                status = True
            except:
                status = False
        else:
            try:
                req = requests.get(url=self.url,headers=self.headers,timeout=12)
                status = True
            except:
                status = False
        if status:
            return req.content
        else:
            return False

web = browser()

def encode_b64(string):
    try:
        string = string.encode('utf-8')
    except:
        pass
    try:
        base64_string = base64.b64encode(string).decode('utf-8')
    except:
        base64_string = base64.b64encode(string)
    return base64_string

def decode_b64(string):
    try:
        decode = base64.b64decode(string).decode('utf-8')
    except:
        decode = base64.b64decode(string)
    return decode

def validar_login(usuario,senha,url):
    usuario = decode_b64(usuario)
    senha = decode_b64(senha)
    url = decode_b64(url)
    return usuario, senha, url

def decodificar_login(usuario,senha):
    usuario = decode_b64(usuario)
    senha = decode_b64(senha)
    return usuario, senha
