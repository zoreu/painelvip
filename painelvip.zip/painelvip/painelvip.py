import os
import sys
import time 
from flask import Flask, Response, session, url_for, send_file, send_from_directory, redirect, render_template, request, stream_with_context, flash
import hashlib
from managerdb import checar_login, mudar_senha, adicionar_usuario, deletar_usuario, listar_usuarios, renovar_vip, acesso_usuario, adicionar_usuario_teste, listar_usuarios2, vencimento_login, backup_db
from navegador import web, validar_login, decodificar_login


app = Flask(__name__, static_url_path='')
app.secret_key='hsdjcjhvnvmlçiihhsyttddbnmvdsr'
porta_servidor = 80


@app.route('/',methods=['GET', 'POST'])
def index():
    return redirect(url_for('painel'))

#fazer login no painel
@app.route('/login', methods=['GET', 'POST'])
def login():
    ok = False
    if request.method=='POST':
        usuario = request.form.get('username')
        senha = request.form.get('password')
        if usuario and senha:
            row = checar_login(usuario,senha)
            if row:
                tipo = row[3]
                if tipo == 'admin':
                    session['usuario'] = usuario
                    ok = True
                    #return redirect(url_for('painel'))
    #return render_template('login.html')
    if not ok:
        flash('Login invalido ou não é admin')
    return redirect(url_for('painel'))

@app.route('/trocarsenha', methods=['GET', 'POST'])
def trocarsenha():
    if 'usuario' in session:
        if request.method=='POST':
            usuario = request.form.get('username')
            senha = request.form.get('password')
            if usuario and senha:
                ok = mudar_senha(usuario,senha)
                if ok:
                    flash('senha trocada com sucesso')
                else:
                    flash('Falha ao trocar senha')
    return redirect(url_for('painel'))

@app.route('/adicionar', methods=['GET', 'POST'])
def adicionar():
    if 'usuario' in session:
        if request.method=='POST':
            usuario = request.form.get('username')
            senha = request.form.get('password')
            if usuario and senha:
                ok = adicionar_usuario(usuario,senha)
                if ok:
                    flash('Usuário Adicionado com sucesso')
                else:
                    flash('Usuário já existe, escolha outro nome de usuário!')
    return redirect(url_for('painel'))

@app.route('/adicionar2', methods=['GET', 'POST'])
def adicionar2():
    if 'usuario' in session:
        if request.method=='POST':
            usuario = request.form.get('username')
            senha = request.form.get('password')
            if usuario and senha:
                ok = adicionar_usuario_teste(usuario,senha)
                if ok:
                    flash('Usuário Adicionado com sucesso')
                else:
                    flash('Usuário já existe, escolha outro nome de usuário!')
    return redirect(url_for('painel'))    

@app.route('/deletar', methods=['GET', 'POST'])
def deletar():
    if 'usuario' in session:
        if request.method=='POST':
            usuario = request.form.get('username')
            if usuario:
                ok = deletar_usuario(usuario)
                if ok:
                    flash('Usuário removido com sucesso!')
                else:
                    flash('Usuário é admin e não pode ser removido!')
    return redirect(url_for('painel'))

@app.route('/deletar2', methods=['GET', 'POST'])
def deletar2():
    if 'usuario' in session:
        usuario = request.args.get('username')
        if usuario:
            ok = deletar_usuario(usuario)
            if ok:
                flash('Usuário removido com sucesso!')
            else:
                flash('Usuário é admin e não pode ser removido!')
    return redirect(url_for('painel'))

@app.route('/renovar', methods=['GET', 'POST'])
def renovar():
    if 'usuario' in session:
        if request.method=='POST':
            usuario = request.form.get('username')
            if usuario:
                ok = renovar_vip(usuario)
                if ok:
                    flash('Vip renovado com sucesso!')
                else:
                    flash('Usuário é admin e tem vip infinito!')
    return redirect(url_for('painel'))

@app.route('/renovar2', methods=['GET', 'POST'])
def renovar2():
    if 'usuario' in session:
        usuario = request.args.get('username')
        if usuario:
            ok = renovar_vip(usuario)
            if ok:
                flash('Vip renovado com sucesso!')
            else:
                flash('Usuário é admin e tem vip infinito!')
    return redirect(url_for('painel'))



#logout do login
@app.route('/logout')
def logout():
    session.pop('usuario',None)
    return redirect(url_for('painel'))

@app.route('/teste')
def teste():
    usuario = session.get('usuario')
    return str(usuario)

#painel
@app.route('/painel',methods=['GET', 'POST'])
def painel():
    login=False
    usuario = ''
    if 'usuario' in session:
        usuario = session.get('usuario')
        login=True 
    action = request.args.get('action')   
    usuario2 = request.args.get('username')
    if not usuario2:
        usuario2 = ''
    trocarsenha = False
    adicionarusuario = False
    adicionarteste = False
    deletar = False
    usuarios = False
    renovar = False
    pesquisar = False
    pix = False
    if action:
        if login:
            if 'trocarsenha' in action:
                trocarsenha = True
            elif 'adicionarusuario' in action:
                adicionarusuario = True
            elif 'adicionarteste' in action:
                adicionarteste = True
            elif 'deletar' in action:
                deletar = True
            elif 'listar' in action:
                if usuario2:
                    usuarios = listar_usuarios2(usuario2)
                else:              
                    usuarios = listar_usuarios()
            elif 'renovar' in action:
                renovar = True
            elif 'pesquisar' in action:
                pesquisar = True
        if 'pix' in action:
            pix = True
    return render_template('login_home.html',**locals())    


@app.route('/acesso',methods=['GET', 'POST'])
def acesso():
    usuario = request.args.get('username')
    senha = request.args.get('password')
    url = request.args.get('url')
    if usuario and senha and url:
        try:
            usuario, senha, url = validar_login(usuario,senha,url)
            ok = acesso_usuario(usuario,senha)
            if ok:
                html = web.get_url(url)
                if not html:
                    html = web.get_url(url)
                if html:
                    return Response(html, mimetype='text/plain')
                else:
                    print('Falha ao acessar o site pelo painel')
        except:
            print('Usuario invalido')
    return 'expirado'

@app.route('/vencimento',methods=['GET', 'POST'])
def vencimento():
    usuario = request.args.get('username')
    senha = request.args.get('password')
    if usuario and senha:
        try:
            usuario, senha = decodificar_login(usuario,senha)
            data = vencimento_login(usuario,senha)
            return Response(data, mimetype='text/plain')
        except:
            print('Falha ao verificar vencimento')
    return 'desconhecido'

@app.route('/backup')
def backup():
    try:
        backup_db()
    except:
        pass
    return 'backup concluido'


def start_flaskapp():
	app.run(host='0.0.0.0', port=porta_servidor)


if __name__ == '__main__':
    start_flaskapp()