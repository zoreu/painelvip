import sqlite3
import hashlib
from datetime import datetime, timezone, timedelta, date
import os
import os.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
db = os.path.join(BASE_DIR, "users.db")
backup_db = os.path.join(BASE_DIR, "backup.db")

def criar_conexao(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except sqlite3.Error as e:
        print(str(e))

    return conn

def create_table():
    sql = '''
CREATE TABLE "login" (
	"usuario"	TEXT,
	"senha"	TEXT,
	"expira"	NUMERIC,
	"tipo"	TEXT,
	"vencimento"	TEXT
    );
    '''
    conn = criar_conexao(db)
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.close()

def checar_pra_inserir(usuario):
    sql = "SELECT * FROM login WHERE usuario = '{0}'".format(str(usuario))
    conn = criar_conexao(db)
    if conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        row = cursor.fetchone()
        if row:
            return True
    return False

def checar_admin(usuario):
    sql = "SELECT * FROM login WHERE usuario = '{0}' AND tipo = 'admin'".format(str(usuario))
    conn = criar_conexao(db)
    if conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        row = cursor.fetchone()
        if row:
            return True
    return False

def checar_usuario(usuario,senha):
    sql = "SELECT * FROM login WHERE usuario = '{0}' AND senha = '{1}'".format(str(usuario),str(senha))
    conn = criar_conexao(db)
    if conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        row = cursor.fetchone()
        if row:
            return row
    return False

def inserir_usuario(usuario,senha,expira,tipo,vencimento):
    existe = checar_pra_inserir(usuario)
    ok = False
    if not existe:
        sql = "INSERT INTO login (usuario, senha, expira, tipo, vencimento) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}')".format(str(usuario),str(senha),str(expira),str(tipo),str(vencimento))
        conn = criar_conexao(db)
        if conn:
            cursor = conn.cursor()
            cursor.execute(sql)
            conn.commit()
            conn.close()
            print('dados inseridos')
            ok = True
        else:
            print('Falha')
    return ok
    


def atualizar_usuario(usuario,expira,vencimento):
    sql = "UPDATE login set expira = '{0}', vencimento = '{1}' WHERE usuario = '{2}'".format(expira,str(vencimento),str(usuario))
    conn = criar_conexao(db)
    if conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        conn.commit()
        conn.close()
        print('dados atualizados')
    else:
        print('Falha')

def atualizar_senha(usuario,senha):
    ok = False
    sql = "UPDATE login set senha = '{0}' WHERE usuario = '{1}'".format(str(senha),str(usuario))
    conn = criar_conexao(db)
    if conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        conn.commit()
        conn.close()
        print('dados atualizados')
        ok = True
    else:
        print('Falha')
    return ok

def atualizar_vip(usuario,expira,vencimento):
    ok = False
    sql = "UPDATE login set expira = '{0}', vencimento = '{1}' WHERE usuario = '{2}'".format(expira,str(vencimento),str(usuario))
    conn = criar_conexao(db)
    if conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        conn.commit()
        conn.close()
        print('dados atualizados')
        ok = True
    else:
        print('Falha')
    return ok    

def deletar_usuario(usuario):
    existe = checar_admin(usuario)
    ok = False
    if not existe:
        sql = "DELETE FROM login WHERE usuario = '{0}'".format(str(usuario))
        conn = criar_conexao(db)
        if conn:
            cursor = conn.cursor()
            cursor.execute(sql)
            conn.commit()
            conn.close()
            print('dados deletados')
            ok = True
        else:
            print('Falha')
    return ok

def exibir_usuarios():
    sql = "SELECT * FROM login"
    conn = criar_conexao(db)
    if conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        rows = cursor.fetchall()
    else:
        rows = False
    return rows

def login_usuario(usuario,senha):
    sql = "SELECT * FROM login WHERE usuario = '{0}' AND senha = '{1}'".format(str(usuario),str(senha))
    conn = criar_conexao(db)
    if conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        row = cursor.fetchone()
        if row:
            print('{0} logado!'.format(usuario))
            return row
    print('Falha de login de {0}'.format(usuario))
    return False

#print(login_usuario('admin','123'))
#print(exibir_usuarios())

def criar_admin():
    usuario = 'admin'
    senha = '123'
    expira = 0
    tipo = 'admin'
    vencimento = 'indeterminado'
    try:
        try:
            senha = senha.encode('utf-8')
        except:
            pass
        hash_object = hashlib.sha256(senha)
        senha = hash_object.hexdigest()
        ok = inserir_usuario(usuario,senha,expira,tipo,vencimento)
        print('{0} criado!'.format(usuario))
    except:
        print('Falha ao criar admin')


#### comeca aqui

def checar_login(usuario,senha):
    try:
        try:
            senha = senha.encode('utf-8')
        except:
            pass
        hash_object = hashlib.sha256(senha)
        senha = hash_object.hexdigest()
    except:
        senha = False
    if senha:    
        row = login_usuario(usuario,senha)
        if row:
            return row
    return False


def mudar_senha(usuario,senha):
    try:
        try:
            senha = senha.encode('utf-8')
        except:
            pass
        hash_object = hashlib.sha256(senha)
        senha = hash_object.hexdigest()
    except:
        senha = False 
    if senha:   
        ok = atualizar_senha(usuario,senha)
    else:
        ok = False
    return ok

def tempo_vip():
    data_e_hora_atuais = datetime.now()
    diferenca = timedelta(hours=-3)
    fuso_horario = timezone(diferenca)
    data_e_hora_sao_paulo = data_e_hora_atuais.astimezone(fuso_horario) + timedelta(days = 30)
    tempo_vip = data_e_hora_sao_paulo.strftime("%Y%m%d%H%M")
    vencimento = str(data_e_hora_sao_paulo.strftime("%d/%m/%Y %H:%M"))
    return tempo_vip, vencimento

def tempo_teste():
    data_e_hora_atuais = datetime.now()
    diferenca = timedelta(hours=-3)
    fuso_horario = timezone(diferenca)
    data_e_hora_sao_paulo = data_e_hora_atuais.astimezone(fuso_horario) + timedelta(hours = 24)
    tempo_teste = data_e_hora_sao_paulo.strftime("%Y%m%d%H%M")
    vencimento = str(data_e_hora_sao_paulo.strftime("%d/%m/%Y %H:%M"))
    return tempo_teste, vencimento

def tempo_atual():
    data_e_hora_atuais = datetime.now()
    diferenca = timedelta(hours=-3)
    fuso_horario = timezone(diferenca)
    data_e_hora_sao_paulo = data_e_hora_atuais.astimezone(fuso_horario)
    tempo_atual = data_e_hora_sao_paulo.strftime("%Y%m%d%H%M")
    return tempo_atual

def checar_tempo(expire):
    t = tempo_atual()
    if expire > int(t):
        ok = True
    else:
        ok = False
    return ok

def adicionar_usuario(usuario,senha):
    expira, vencimento = tempo_vip()
    ok = False
    try:
        try:
            senha = senha.encode('utf-8')
        except:
            pass
        hash_object = hashlib.sha256(senha)
        senha = hash_object.hexdigest()
    except:
        senha = False
    if senha:    
        ok = inserir_usuario(usuario,senha,expira,'vip',vencimento)
    if ok:
        print('Usuario adicionado')
    else:
        print('Usuario ja existe')
    return ok

def adicionar_usuario_teste(usuario,senha):
    expira, vencimento = tempo_teste()
    ok = False
    try:
        try:
            senha = senha.encode('utf-8')
        except:
            pass
        hash_object = hashlib.sha256(senha)
        senha = hash_object.hexdigest()
    except:
        senha = False
    if senha:    
        ok = inserir_usuario(usuario,senha,expira,'vip',vencimento)
    if ok:
        print('Usuario adicionado')
    else:
        print('Usuario ja existe')
    return ok    

def acesso_usuario(usuario,senha):
    condicao = False
    try:
        try:
            senha = senha.encode('utf-8')
        except:
            pass
        hash_object = hashlib.sha256(senha)
        senha = hash_object.hexdigest()
    except:
        senha = False
    if senha:    
        row = checar_usuario(usuario,senha)
        if row:
            expira = row[2]
            if expira == 0:
                condicao = True
            else:
                if checar_tempo(expira):
                    condicao = True
                else:
                    condicao = False
        else:
            print('Usuario invalido')
    return condicao



def renovar_vip(usuario):
    ok = False
    expira, vencimento = tempo_vip()
    existe = checar_admin(usuario)
    if not existe:
        ok = atualizar_vip(usuario,expira,vencimento)
        if ok:
            print('Vip atualizado')
        else:
            print('Falha ao atualizar vip')
    return ok

def listar_usuarios():
    sql = "SELECT * FROM login"
    conn = criar_conexao(db)
    usuarios = []
    if conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            for usuario,senha,expira,tipo,vencimento in row:
                if expira == 0:
                    condicao = 'Infinito'
                else:
                    if checar_tempo(expira):
                        condicao = 'Ativo'
                    else:
                        condicao = 'Expirado'
                usuarios.append((usuario,condicao,vencimento))
    return usuarios

def listar_usuarios2(usuario):
    sql = "SELECT * FROM login WHERE usuario like '%"+str(usuario)+"%' ORDER BY usuario"
    conn = criar_conexao(db)
    usuarios = []
    if conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            for usuario,senha,expira,tipo,vencimento in row:
                if expira == 0:
                    condicao = 'Infinito'
                else:
                    if checar_tempo(expira):
                        condicao = 'Ativo'
                    else:
                        condicao = 'Expirado'
                usuarios.append((usuario,condicao,vencimento))
    return usuarios


def vencimento_login(usuario,senha):
    vencimento = 'desconhecido'
    try:
        try:
            senha = senha.encode('utf-8')
        except:
            pass
        hash_object = hashlib.sha256(senha)
        senha = hash_object.hexdigest()
    except:
        senha = False
    if senha:    
        sql = "SELECT * FROM login WHERE usuario = '{0}' AND senha = '{1}'".format(str(usuario),str(senha))
        conn = criar_conexao(db)
        if conn:
            cursor = conn.cursor()
            cursor.execute(sql)
            row = cursor.fetchone()
            if row:
                vencimento = row[4]
    return vencimento


#vencimento_login('admin','123')
#criar_admin()
def create_table_backup():
    sql = '''
CREATE TABLE "login" (
	"usuario"	TEXT,
	"senha"	TEXT,
	"expira"	NUMERIC,
	"tipo"	TEXT,
	"vencimento"	TEXT
    );
    '''
    conn = criar_conexao(backup_db)
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.close()

def inserir_usuario_backup(usuario,senha,expira,tipo,vencimento):
    sql = "INSERT INTO login (usuario, senha, expira, tipo, vencimento) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}')".format(str(usuario),str(senha),str(expira),str(tipo),str(vencimento))
    conn = criar_conexao(backup_db)
    if conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        conn.commit()
        conn.close()
        print('dados inseridos')
        ok = True
    else:
        print('Falha')
    return ok

def backup_db():
    sql = "SELECT * FROM login"
    conn = criar_conexao(db)
    if conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            try:
                os.remove(backup_db)
            except:
                pass
            try:
                create_table_backup()
            except:
                pass
            for usuario, senha, expira, tipo, vencimento in row:
                inserir_usuario_backup(usuario,senha,expira,tipo,vencimento)




