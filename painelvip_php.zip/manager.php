<?php

include 'conn.php';

function checar_pra_inserir($usuario,$db) {
    if($db != false){
        $sql = "SELECT * FROM login WHERE usuario = '$usuario'";
        $res = $db->query($sql);
        $row = $res->fetchArray();
        if(empty($row)){
            $total = 0;
        } else {
            $total = count($row);
        }
        //echo $total;
        //echo $row['usuario'];
        //if ($total > 0){
        //    echo 'existe';
        //} else {
        //    echo 'nao existe';
        //}

    //}    
        //while ($row = $res->fetchArray()) {
        //    //echo "{$row['id']} {$row['name']} {$row['price']} \n";
        //    //echo "{$row['id']} {$row['name']} {$row['price']} \n";
        //    echo $row['usuario'];
        //}        

    } else {
        $total = 0;
    }
    if ($total > 1){
        return true;
    } else {
        return false;
    }

}

function checar_admin($usuario,$db) {
    if($db != false){
        $sql = "SELECT * FROM login WHERE usuario = '$usuario' AND tipo = 'admin'";
        $res = $db->query($sql);
        $row = $res->fetchArray();
        if(empty($row)){
            $total = 0;
        } else {
            $total = count($row);
        }
        //echo $total;
        //echo $row['usuario'];
        //if ($total > 0){
        //    echo 'existe';
        //} else {
        //    echo 'nao existe';
        //}

    //}    
        //while ($row = $res->fetchArray()) {
        //    //echo "{$row['id']} {$row['name']} {$row['price']} \n";
        //    //echo "{$row['id']} {$row['name']} {$row['price']} \n";
        //    echo $row['usuario'];
        //}        

    } else {
        $total = 0;
    }
    if ($total > 1){
        return true;
    } else {
        return false;
    }    

}

function checar_usuario($usuario,$senha,$db){
    if($db != false){
        $sql = "SELECT * FROM login WHERE usuario = '$usuario' AND senha = '$senha'";
        $res = $db->query($sql);
        //$row = $res->fetchArray();
        return $res;
    } else {
        return false;
    }


}

function inserir_usuario($usuario,$senha,$expira,$tipo,$vencimento,$db) {
    if($db != false){
        $existe = checar_pra_inserir($usuario,$db);
        if ($existe != true) {
            $sql = "INSERT INTO login(usuario, senha, expira, tipo, vencimento) VALUES('$usuario', '$senha', '$expira', '$tipo', '$vencimento')";
            $db->exec($sql);
            return true;
        } else {
            return false;
        }
    
    } else {
        return false;
    }

}    


function atualizar_usuario($usuario,$expira,$vencimento,$db) {
    if($db != false){
        $sql = "UPDATE login SET expira = '$expira', vencimento = '$vencimento' WHERE usuario = '$usuario'";
        $db->exec($sql);
    }
}

function atualizar_senha($usuario,$senha,$db) {
    if($db != false){
        $sql = "UPDATE login SET senha = '$senha' WHERE usuario = '$usuario'";
        $db->exec($sql);
    }
}

function atualizar_vip($usuario,$expira,$vencimento,$db) {
    if($db != false){
        $sql = "UPDATE login SET expira = '$expira', vencimento = '$vencimento' WHERE usuario = '$usuario'";
        $db->exec($sql);
        return true;
    } else {
        return false;
    }
}

function deletar_usuario($usuario,$db) {
    if($db != false){
        $existe = checar_admin($usuario,$db);
        if ($existe != true) {
            $sql = "DELETE FROM login WHERE usuario = '$usuario'";
            $db->exec($sql);
            return true;
        } else {
            return false;
        }
    
    } else {
        return false;
    }

}

function login_usuario($usuario,$senha,$db){
    if($db != false){
        $sql = "SELECT * FROM login WHERE usuario = '$usuario' AND senha = '$senha'";
        $res = $db->query($sql);
        $row = $res->fetchArray();
        if(empty($row)){
            $total = 0;
        } else {
            $total = count($row);
        }    

    } else {
        $total = 0;
    }
    if ($total > 1){
        return $row;
    } else {
        return false;
    }

}
// inicia aqui

function checar_login($usuario,$senha,$db){
    if($db != false){
        $senha_sha256 = hash('sha256', $senha);
        $row = login_usuario($usuario,$senha_sha256,$db);
        return $row;
    }
}

function mudar_senha($usuario,$senha,$db){
    if($db != false){
        $senha_sha256 = hash('sha256', $senha);
        atualizar_senha($usuario,$senha_sha256,$db);
    }
}

function tempo_vip(){
    date_default_timezone_set('America/Sao_Paulo');
    //$data_pagamento = date('Y-m-d H:i:s' , strtotime('+1 hours'));
    $tempovip = date('YmdHi' , strtotime('+30 days'));
    $vencimento = date('d/m/Y H:i' , strtotime('+30 days'));
    return array($tempovip,$vencimento);
}

function tempo_teste(){
    date_default_timezone_set('America/Sao_Paulo');
    $tempoteste = date('YmdHi' , strtotime('+24 hours'));
    $vencimento = date('d/m/Y H:i' , strtotime('+24 hours'));
    return array($tempoteste,$vencimento);
}

function tempo_atual(){
    date_default_timezone_set('America/Sao_Paulo');
    $tempo_atual = date('YmdHi');
    //$vencimento = date('d/m/Y H:i' , strtotime('+24 hours'));
    return $tempo_atual;
}

function checar_tempo($expire){
    $t = tempo_atual();
    if ($expire == 0){
        return true;
    } elseif ((int)$expire >= (int)$t){
        return true;
    } else {
        return false;
    }
}

function condicao_vip($expire){
    $cond = checar_tempo($expire);
    if ($expire == 0){
        return 'Vip Infinito';
    }elseif ($cond !=false){
        return 'Vip Ativo';
    } else {
        return 'Vip expirado';
    }
}

//listar usuarios
function exibir_usuarios($db) {
    if($db != false){
        $sql = "SELECT * FROM login";
        $res = $db->query($sql);
        echo '<ul>';
        while ($row = $res->fetchArray()){
           //echo $row['usuario'];
           echo '<li><p>Usuário: '.$row['usuario'].', Vip: '.condicao_vip($row['expira']).', Vencimento: '.$row['vencimento'].' | <a href="../index.php?action=renovar&username='.$row['usuario'].'">Renovar VIP</a> | <a href="../index.php?action=trocarsenha&username='.$row['usuario'].'">Trocar senha</a> | <a href=""../index.php?action=deletar&username='.$row['usuario'].'"">Remover</a></p></li>';
        }
        echo '</ul>';
    } else {
        echo 'Nehum usuário encontrado!';
    }
}

function exibir_usuarios2($usuario,$db) {
    if($db != false){
        //$sql = "SELECT * FROM login";
        //$sql = "SELECT * FROM login WHERE usuario LIKE '%$usuario%'") or die("Failed to fetch row!");
        $sql = "SELECT * FROM login WHERE usuario LIKE '%".$usuario."%'");
        $res = $db->query($sql);
        echo '<ul>';
        while ($row = $res->fetchArray()){
           //echo $row['usuario'];
           echo '<li><p>Usuário: '.$row['usuario'].', Vip: '.condicao_vip($row['expira']).', Vencimento: '.$row['vencimento'].' | <a href="../index.php?action=renovar&username='.$row['usuario'].'">Renovar VIP</a> | <a href="../index.php?action=trocarsenha&username='.$row['usuario'].'">Trocar senha</a> | <a href=""../index.php?action=deletar&username='.$row['usuario'].'"">Remover</a></p></li>';
        }
        echo '</ul>';
    } else {
        echo 'Nehum usuário encontrado!';
    }
}

exibir_usuarios2('teste',$db);

// pegar tempo vip
//list($tempovip,$vencimento) = tempo_vip();
//echo $tempovip;

// pegar tempo teste
//list($tempoteste,$vencimento) = tempo_teste();
//echo $tempoteste;


// checar tempo
//$cond_vip = checar_tempo(202203272324);
//if ($cond_vip !=false){
//    echo 'vip ativo';
//} else {
//    echo 'vip expirado';
//}
//////////////////

//atualizar_usuario('admin','1','vencimento',$db)


//echo checar_pra_inserir('admin',$db);
//$cond = var_export(checar_pra_inserir('admin',$db),true);
//$cond = checar_pra_inserir('admin1',$db);
//$cond = var_export(checar_admin('admin',$db),true);
//echo $cond;

//inserir_usuario('teste','123','0','vip','indeterminado',$db);
//$existe = checar_pra_inserir('teste', $db);
//teste($db);

//deletar_usuario('admin',$db)

function adicionar_usuario($usuario,$senha,$db){
    if($db != false){
        list($tempovip,$vencimento) = tempo_vip();
        $senha_sha256 = hash('sha256', $senha);
        $cond = inserir_usuario($usuario,$senha_sha256,$tempovip,'vip',$vencimento,$db);
        return $cond;
    } else {
        return false;
    }

}

function adicionar_usuario_teste($usuario,$senha,$db){
    if($db != false){
        list($tempoteste,$vencimento) = tempo_teste();
        $senha_sha256 = hash('sha256', $senha);
        $cond = inserir_usuario($usuario,$senha_sha256,$tempoteste,'vip',$vencimento,$db);
        return $cond;
    } else {
        return false;
    }

}

function acesso_usuario($usuario,$senha,$db){
    $cond = false;
    if($db != false){
        $senha_sha256 = hash('sha256', $senha);
        $res = checar_usuario($usuario,$senha_sha256,$db);
        $i = 0;
        while ($row = $res->fetchArray()){
            $i++;
            if ($i == 1){
                $expira = $row['expira'];
                $cond = checar_tempo($expira);
                break;
            }
            
        }
    }
    return $cond;
}

function renovar_vip($usuario,$db){
    if($db != false){
        list($tempovip,$vencimento) = tempo_vip();
        $existe = checar_admin($usuario,$db);
        if ($existe !=true){
            $ok = atualizar_vip($usuario,$tempovip,$vencimento,$db);
            if ($ok !=false){
                echo 'Vip renovado!';
            } else {
                echo 'falha ao renovar vip!';
            }

        } else {
            echo 'falha ao renovar vip!';

        }
    } else {
        echo 'falha ao renovar vip!';
    }
}


//$vip = var_export(acesso_usuario('teste2','123',$db),true);
//echo $vip;

//acesso_usuario('teste','123',$db);


//adicionar_usuario_teste('teste2','123',$db);

//exibir_usuarios($db);
// exibir usuario
//$res = exibir_usuarios($db);
//while ($row = $res->fetchArray()){
//    echo $row['usuario'];
//}

//renovar_vip('teste2',$db);

?>